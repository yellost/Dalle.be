
    <template>
<main>
        <div class="map">
            <img src="~@/assets/img/mapaa.jpg" alt="#">
            <div class="titl">
            <h1> Touch  <span class="pLetter">here</span> and look around you!</h1>
        </div>
        </div>
        <article>
            <button type="submit" form="form1" value="Submit" class="filter">Filtrer</button>
            <section class="post">
                <div class="imgResto">
                    <img src="~@/assets/img/durum.gif" alt="#">
                </div>
                <div class="info">
                    <h3>Resto 1</h3>
                    <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quaerat, ab. </p>
                </div>
            </section>
            <section class="post">
                <div class="imgResto">
                    <img src="~@/assets/img/steak.gif" alt="">
                </div>
                <div class="info">
                    <h3>Resto 1</h3>
                    <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quaerat, ab. </p>
                </div>
            </section>
            <section class="post">
                    <div class="imgResto">
                        <img src="~@/assets/img/durum.gif" alt="#">
                    </div>
                    <div class="info">
                        <h3>Resto 1</h3>
                        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quaerat, ab. </p>
                    </div>
            </section>
        </article>


    </main>
</template>

<script>
// @ is an alias to /src
import HelloWorld from '@/components/HelloWorld.vue'

export default {
  name: 'HomeMain',
  components: {
  }
}
</script>