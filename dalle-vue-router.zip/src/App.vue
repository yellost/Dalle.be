<template>
  <div id="app">
      <!-- <router-link to="/home">Home</router-link> |
      <router-link to="/resto">Resto</router-link> |
      <router-link to="/admin">Admin</router-link>
    <router-view/> --><!-- header -->
    
    <!-- end header -->
    

    <footer>
        <div class="logoFoot">
            <img src="~@/assets/img/logo.png" alt="">
        </div>
        <p>info@dalle.be</p>
    </footer>

  </div>
</template>

<style>
 @import './assets/css/style.min.css'
</style>
